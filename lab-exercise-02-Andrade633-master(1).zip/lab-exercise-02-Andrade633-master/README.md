# Lab exercise 2
Author: `<Place your name here>`
