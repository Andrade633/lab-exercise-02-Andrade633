// Describe your program
#include <iostream>
using namespace std;
int main()
{
	// variable declaration
	// Describe your algorithm
	
	return 0;
}
