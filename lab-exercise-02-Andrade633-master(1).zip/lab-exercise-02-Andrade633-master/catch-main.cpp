// File used to generate object file for faster compilation
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
